package com.convertor.solution2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.convertor.solution2.service.ConversionsService;

@RestController
@RequestMapping("/conversions/")
public class ConversionsController {

	@Autowired
	private ConversionsService conversionsService;
	
	@GetMapping("/ktoc/{amount}")
	public Double  celsiusToKelvin(@PathVariable Double amount) {
		return conversionsService.celsiusToKelvin(amount);
	} 
	
	@GetMapping("/ctok/{amount}")
	public Double  kelvinToCelsius(@PathVariable Double amount) {
		return conversionsService.kelvinToCelsius(amount);
	} 
	
	@GetMapping("/mtok/{amount}")
	public Double  milesTokm(@PathVariable Double amount) {
		return conversionsService.milesTokm(amount);
	} 
	
	@GetMapping("/ktom/{amount}")
	public Double  kmTomiles(@PathVariable Double amount) {
		return conversionsService.kmTomiles(amount);
	} 
	
}

package com.convertor.solution2.service;

import org.springframework.stereotype.Service;

@Service
public class ConversionsService {

	public double celsiusToKelvin(double degreeInCelsius) {
		return degreeInCelsius - 273.15F;
	}

	public double kelvinToCelsius(double degreeInKelvin) {
		return degreeInKelvin + 273.15F;
	}

	public double milesTokm(double distanceInMiles) {
		return distanceInMiles * 1.60934;
	}

	public double kmTomiles(double distanceInKm) {
		return distanceInKm * 0.621371;
	}
}
